# Discord.js Example Bot
Best Kit Repository For Starter!

In this Repository, you can use this Code for your **New Discord Bot**s.
This Repo is served with little kind of Basic Command that you can learn it.

You can host this on Heroku, just click this **Deploy** button below :


<a href="https://heroku.com/deploy?template=https://github.com/fschxspam/discord.js-example-bot/tree/master">
  <img src="https://www.herokucdn.com/deploy/button.svg" alt="Deploy">
</a>


1. Input your **Bot Token**, and Input your Bot **Prefixes**. Get your Bot's Token in your App Settings.
2. After *Deployed*, Go to **Overview** Tabs >  **Configure Dynos** > Enable **worker** Dynos > Click **Confirm**
and you Ready to Go!
